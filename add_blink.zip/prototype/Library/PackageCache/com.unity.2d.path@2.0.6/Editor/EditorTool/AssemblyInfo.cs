using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Unity.2D.SpriteShape.Editor")]
