﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class Gameover : MonoBehaviour
{
    //　ゲームオーバー時に表示するUIのプレハブ
    [SerializeField] private GameObject GmeoverUIPrefab;
    //　ゲームオーバーUIのインスタンス
    private GameObject GameoverUIInstance;

    private bool OnGameover;

    // プレイヤーの体力取得
    GameObject bird;
    Player p;

    private void Start()
    {
        bird = GameObject.Find("Player");
        p = bird.GetComponent<Player>();

        OnGameover = false;
    }

    void Update()
    {
        if (OnGameover)
        {
            // ステージリスタート
            if (Input.GetButtonDown("Button_X"))
            {
                SceneManager.LoadScene("GameScene", LoadSceneMode.Single);
            }
        }
    }


    public void SetGameover()
    {
        if (GameoverUIInstance == null)
        {
            GameoverUIInstance = GameObject.Instantiate(GmeoverUIPrefab) as GameObject;
            Time.timeScale = 0f;
            OnGameover = true;
        }
        else
        {
            Destroy(GameoverUIInstance);
            Time.timeScale = 1f;
            OnGameover = false;
        }
    }
}